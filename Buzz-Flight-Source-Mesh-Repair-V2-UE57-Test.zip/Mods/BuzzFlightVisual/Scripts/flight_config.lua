-- Isolated Windows source-mesh / flight / optional tuft visual test.
return {Enabled=true,DebugToggleKey=nil}
