-- Isolated Windows flight-pose test; remove this mod to return to v0.3.
return {Enabled=true,DebugToggleKey=nil}
