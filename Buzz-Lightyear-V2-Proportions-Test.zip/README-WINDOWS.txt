BUZZ V2 - PROPORTIONS AND NORMAL-TEXTURE TEST
Grounded 2 PC Game Pass / WinGDK build 0.316.9020.0
V2 IS NOT YET TESTED IN GAME. V1 remains the Windows-verified baseline.

INSTALL
1. Close Grounded 2.
2. Move the existing zBuzzAtlasTest_P.pak/.utoc/.ucas OUTSIDE the entire Paks tree.
   Keep that working trio and its ZIP as a backup. Also move Commander101,
   zMeshTest_P and any other Max skin overrides outside Paks.
3. Copy ONLY zBuzzAtlasV2_P.pak, zBuzzAtlasV2_P.utoc, zBuzzAtlasV2_P.ucas from
   this ZIP directly into Augusta/Content/Paks.
   Your known installation: C:\XboxGames\Grounded 2\Content\Augusta\Content\Paks
4. Never change Augusta-WinGDK.*, global.*, original game files or save files.
5. Launch and select Max.

ROLL BACK
Close game. Move the V2 trio outside Paks. Restore the backed-up V1 trio.
Do not install both versions simultaneously; they override the same Max assets.

WHAT CHANGED
- Broader torso and limbs, source-proportion uniform head scaling.
- Larger boots; visual shin length restored near the source rather than stretched.
- Rigid spherical knee/elbow joint pieces to reduce blended-shell collapse.
- Replaced a faulty "flat" BC5 normal map. V1 decoded into alternating128/255
  columns, explaining the visible stripe pattern. V2 independently decodes to
  constant128,128 at every mip. The tangent-buffer encoding was not changed.

WHAT STAYS IDENTICAL
Original230-bone reference rest transforms/order, game skeleton/animation refs,
private material instance, base-color atlas, RMA/SSS textures, physics and hair
assets. Only two mesh packages and the normal texture export/bulk differ; the
new basename has its own matching container identity. No movement/input/gliding
mechanic changes or capsule modifications. The original V1 ZIP is unchanged.

PREVIEWS
V2-front-side-sitting.png and front.png/side.png/sitting.png show neutral Blender
lighting and a synthetic pose, not the actual game animation, shader or chair.
Source-unfitted-reference.png shows unchanged source geometry, with wing faces
hidden for comparison. The source T-pose has wider arm span than the preview crop.
The independent audit compares source, V1/V2 authoring, export and native streams.

SCOPE / LIMITATIONS
Fixed game joint spacing limits exact source limb proportions. V2 keeps the
working skeleton, with visual shell/hinge offsets and larger boots. Actual game
sitting, equipment contact and first-person hands may still need refinement.
No new facial expressions, voices or portraits. Shared temporary opaque material,
flat normals and distant atlas mip bleeding remain visual compromises.
Backpack is visible; six extended wing panels remain omitted from gameplay and
preserved in the Blender source with original positions/transforms.

TEST FIRST
Compare V1/V2 standing front/side, seated, crouching and punching under similar
lighting. Check stripes on suit/face, knee/hip/arm deformation, feet contact,
hand/equipment alignment, walking/running/jumping and any crashes. Please send
standing front+side and seated screenshots. No new extraction is needed.

OFFLINE CHECKS
Retoc verify,14packages/19chunks exact raw roundtrip; both native meshes independently
read by CUE4Parse with18,780render vertices and20,124triangles, original skeleton,
intended weights/indices/UVs/materials. All50mips read/hashchecked, normal pixels
independently decoded. Fresh Blender reopen,10controlled poses and source wing
archive checks passed. These checks do not establish V2 runtime compatibility.

SOURCES
Buzz supplied by user from linked Sketchfab model e914bf92026b4fd096fc34dc2760fecc,
gaddiellartey2010. Existing license-term conflict remains documented in project.
Commander101 is a third-party technical reference, not original Grounded 2 art.
User authorized publication of the gameplay test ZIP. V1 source/project untouched.
