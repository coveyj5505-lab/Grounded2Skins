-- User-accepted flight behavior; brief initial tuft flash accepted.
return {Enabled=true,DebugToggleKey=nil}
