-- Combined V3 Windows feature test; stable wing control is unchanged.
return {Enabled=true,DebugToggleKey=nil}
