BUZZ LIGHTYEAR - FIRST WINDOWS GAMEPLAY TEST
Grounded 2 PC Game Pass / WinGDK, build 0.316.9020.0
Mod: zBuzzAtlasTest_P - replaces Max (Player_Male01)

STATUS: independently validated OFFLINE; NOT TESTED in Grounded 2.
This is the first Buzz geometry/texture gameplay test, not a finished release.

INSTALL
1. Close Grounded 2.
2. Move all three files from each conflicting Max skin mod OUTSIDE the entire
   Augusta/Content/Paks folder tree. This includes zCommander101_P,
   zMeshTest_P, and any previous zBuzzGeometry or zBuzzAtlas test files.
   Keep backups elsewhere. Renaming files inside Paks is insufficient.
3. Copy ONLY these three files from this ZIP into Augusta/Content/Paks:
   zBuzzAtlasTest_P.pak
   zBuzzAtlasTest_P.utoc
   zBuzzAtlasTest_P.ucas
   Typical path from your installation:
   C:\XboxGames\Grounded 2\Content\Augusta\Content\Paks
   Put the files directly in Paks, without an extra ZIP/extraction subfolder.
4. Never replace or remove Augusta-WinGDK.*, global.*, or any original game file.
5. Launch the game and select Max. Other active Max mods can override this test.

REMOVE / RESTORE
Close the game. Move the zBuzzAtlasTest_P trio outside Paks. Restore your backed-up
Commander101 trio if wanted. No game files or saves are modified by installation.

TEST AND REPORT
- Does the game launch and Max appear as Buzz with white/green/purple colors?
- Are face/eyes and chest details oriented correctly? Check front and backpack.
- Walk/run, crouch, sit, jump, climb, hold tools, and inspect both hands.
- Note hand/pinky distortion, torso collapse, floating hair or oversized bounds.
- Move close/far to check texture streaming, color changes and atlas seams.
- If the game crashes, remove this trio and report the crash/log plus what action
  triggered it. Restore the working Commander101 mod for comparison if useful.

WHAT THIS TEST PRESERVES
230-bone recovered reference rig, original game USkeleton/animation dependencies,
existing Commander101 custom skeletal physics, original gameplay/input mechanics.
The stock assessment found all 52 Buzz-weighted bones by name, but recovered and
stock rest transforms are not identical. Two pinky orientations differ; no bind
correction was made without animation evidence. Stock physics has 15 body setups
and 14 constraints; Commander has 18 and 17. No stock-equivalence claim is made.

WINGS
Backpack remains visible. Extended wing panels are omitted from the playable mesh.
All six panels, original transforms and eight source images remain in the separate
preserved Blender authoring project. No wing deployment or gliding input changes.

TEMPORARY VISUAL LIMITATIONS
One opaque character material for suit, face and eyes; shared simplified shading.
4096px BC3 atlas, flat normal texture, matte RMA, black subsurface mask.
Fine details are downsampled; distant mip levels can blend atlas cells.
Existing skin effects/lighting may still affect the suit. No new facial animation,
voice, portrait or animation tracks. The game must confirm actual rendered shading.

ISOLATION / VALIDATION
Private material instance and four textures live under /Game/_BuzzMod/.
No original texture or material package path is overridden. Both Max mesh slots
resolve to the private MI; its Albedo resolves to the private atlas. The original
MM_Character parent and cached MI native/shader payload are retained.
Container verification + 19-chunk byte-exact raw roundtrip passed. Both native LODs
were independently read with CUE4Parse (19,609 vertices / 20,124 triangles each).
All 50 texture mips were independently read and hash checked. Source/recovered
skeleton, joint palettes and integer weights remain intact.

Reference credit: Commander101 third-party Max mod supplied by the user; it is
not original Grounded 2 artwork. Buzz source: Sketchfab model
https://sketchfab.com/3d-models/buzz-lightyear-e914bf92026b4fd096fc34dc2760fecc
by gaddiellartey2010, downloaded directly by the user. Listing/nested license terms
conflict; this supplied-source test remains private. Do not treat this archive as
permission for public redistribution.
