-- Isolate wing transitions after native crash; flight pose remains experimental.
return {Enabled=true,DebugToggleKey=nil}
