Buzz flight landing V5 — Windows validation pending

Replace only ue4ss/Mods/BuzzFlightVisual with the folder under Mods in this ZIP. Keep all Paks, BuzzWings, BoPeepCrook and mods.txt unchanged. No asset, skin, camera, physics or equipment changes.

V4's log identifies repeated restoration failures on the old deployed wing and retired dandelion StaticMesh after landing. That cleanup debt blocked later glides. V5 checks transient-component membership before restoration/retry, retires replaced private wings, and attempts restoration of disappearing tuft visuals without making an inactive, rejecting tuft block subsequent glides. Actual native body and wrist-device restoration remains strict and retryable. Existing live tuft visibility still restores normally. F1 manual OR glide state unchanged.

Please test several glides with landings between them. Forward flight should engage on each glide without pausing/screenshotting or restarting. Check F1 preference restoration after landing and FP/TP transitions. Send the latest UE4SS.log.48 mocked Lua groups pass; native Windows behavior is not yet confirmed.

Buzz arm geometry is unchanged and remains unresolved. Bo Peep V4 and accepted Woody/Jessie skins are unchanged. Rollback: restore BuzzFlightVisual from Buzz-BoPeep-Runtime-V4-UE57-Test.zip. No installers.
