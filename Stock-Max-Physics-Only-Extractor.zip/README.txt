STOCK MAX: PHYSICS ONLY (read-only)

Run Start-Extraction.cmd as before; select retoc.exe and original Augusta-WinGDK.utoc.
This extracts only the one physics package actually imported by both stock Max meshes:
/Game/Art/Characters/Player_Male01/Mesh/SK_Male_Kid_01_PhysicsAsset

No need to repeat the four successful extractions. Original game files are not changed.
Upload the resulting Desktop ZIP. Requires the same Python 3.11+ and retoc 0.1.5.
The existing launcher is reused; its Desktop folder still starts Grounded2-StockMax-.
