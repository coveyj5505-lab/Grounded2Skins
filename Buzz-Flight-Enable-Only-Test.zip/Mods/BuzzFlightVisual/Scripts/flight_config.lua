-- Optional third-person glide visual experiment; no wing or skin changes.
return {Enabled=true,DebugToggleKey=nil}
