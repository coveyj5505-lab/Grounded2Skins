-- Read-only installation receipt; this does not claim a file was mounted.
local M={}
local expected={
{name='Rivet-BoPeep_99_P',stem='Rivet-BoPeep_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d080000009000000011000000ee0000000c0000000000000020000000000001004e04000001000000c0c647cd1c365103',sizes={pak=339,utoc=4884,ucas=14796144}},
{name='Rivet-Buzz_99_P',stem='Rivet-Buzz_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d08000000900000000f000000460100000c000000000000002000000000000100d00300000100000075bf3b0d3e2e64bb',sizes={pak=339,utoc=5722,ucas=20654410}},
{name='Rivet-Jessie_99_P',stem='Rivet-Jessie_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d080000009000000010000000f90000000c0000000000000020000000000001002e04000001000000d41efee0e9dcb775',sizes={pak=339,utoc=4938,ucas=15515703}},
{name='Rivet-Woody_99_P',stem='Rivet-Woody_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d080000009000000015000000c80100000c0000000000000020000000000001001e05000001000000a67329c67f4e3ba6',sizes={pak=339,utoc=7892,ucas=28877945}},
{name='Rivet-BoPeep-CrookMesh_99_P',stem='Rivet-BoPeep-CrookMesh_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d080000009000000004000000090000000c000000000000002000000000000100b50100000100000007282675f71eb57d',sizes={pak=339,utoc=873,ucas=497106}},
{name='Rivet-BoPeep-CrookNative_99_P',stem='Rivet-BoPeep-CrookNative_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d0800000090000000030000000b0000000c000000000000002000000000000100e3000000010000007dcc3ce2da8041f9',sizes={pak=347,utoc=641,ucas=552930}},
{name='Rivet-Buzz-Wings_99_P',stem='Rivet-Buzz-Wings_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d08000000900000000c000000c70000000c000000000000002000000000000100650300000100000027ef54510d105472',sizes={pak=339,utoc=3953,ucas=12559150}},
{name='Rivet-Buzz-Flight_99_P',stem='Rivet-Buzz-Flight_99_P',head='2d3d3d2d2d3d3d2d2d3d3d2d2d3d3d2d08000000900000000b000000040100000c0000000000000020000000000001000c030000010000003b1090dc5525fac4',sizes={pak=339,utoc=4550,ucas=16558552}},
}
local old={'zBuzzSkinV2UE57_P','zBoPeepSkinV2UE57_P','zWoodySkinV2UE57_P','zJessieSkinV2UE57_P','zBuzzUE57_P','zBoPeepUE57_P','zWoodyUE57_P','zJessieUE57_P','zBoCrookUE57_P','zBoCrookHandV2UE57_P'}
function M.run(log)
 if not io or type(io.open)~='function' then log('BUILD RECEIPT unavailable: file I/O disabled');return end
 local dirs={'../../Content/Paks/~mods/','../../Content/Paks/','Augusta/Content/Paks/','../../../Augusta/Content/Paks/'}
 for _,item in ipairs(expected) do
  local matched=false
  for _,dir in ipairs(dirs) do
   local f=io.open(dir..item.stem..'.utoc','rb')
   if f then
    local b=f:read(64);f:close();local hex=b and b:gsub('.',function(c)return string.format('%02x',string.byte(c))end) or '';local good=hex==item.head
    for _,ext in ipairs({'pak','utoc','ucas'}) do
     local input=io.open(dir..item.stem..'.'..ext,'rb');local size=input and input:seek('end') or nil;if input then input:close() end
     good=good and size==item.sizes[ext]
    end
    log('BUILD RECEIPT '..item.name..': '..(good and 'FILES MATCH RIVET RC' or 'MISSING/MISMATCHED TRIO')..'; '..dir..item.stem..'; file presence is not mount proof')
    matched=true;break
   end
  end
  if not matched then log('BUILD RECEIPT '..item.name..': MISSING '..item.stem..' trio') end
 end
 for _,stem in ipairs(old) do
  for _,dir in ipairs(dirs) do
   local f=io.open(dir..stem..'.utoc','rb')
   if f then f:close();log('BUILD RECEIPT OLD REPLACEMENT PRESENT: '..dir..stem..'; move its trio outside Paks');break end
  end
 end
end
return M

