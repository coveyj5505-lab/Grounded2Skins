-- Flight pose reliability is pending; cosmetic wings remain enabled separately.
return {Enabled=false,DebugToggleKey=nil}
